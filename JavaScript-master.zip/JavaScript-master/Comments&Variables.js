// This is a single line comment


/*
This is a
multi-line
comment
*/


/*********  Variables **********/

let x;
x = 10;

let x = 10;

let message = 'Hello';
message = 'Welcome';

let x,y;
x=10;
y=20;

let x=10, y=20;

let name;
let Name;

let firstName = 'Raghav';
let lastName = 'Pal';




