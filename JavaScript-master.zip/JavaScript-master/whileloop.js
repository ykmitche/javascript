let counter=11;

while(counter <= 10){

    console.log('counter : '+counter);
    counter=counter+1;
}

counter = 11
do{
    console.log('counter value is : '+counter);
    counter++;
}while(counter <= 10)


let numbers = [1,2,3,4,5];

let fruits = ['Apple', 'Banana', 'Grapes'];

let cars = new Array('Toyota', 'Mercedes', 'Honda');

console.log (numbers);
console.log (fruits);
console.log (cars[1]);

cars[1] = 'Ford';
console.log (cars[1]);

// let person = {firstName:'John', lastName:'Doe', age:25};
// console.log (person);
// console.log (person.firstName);

console.log (cars.length)
console.log (cars);
cars.sort;
console.log (cars);

fruits.push('cherry')
console.log (fruits)
console.log (typeof cars)
console.log (fruits instanceof Array)


