
let age = 18;

if(age > 18){
    console.log ('Congrats, You are eligible to get driving licence');
}
else if(age == 18){
    console.log ('Congrats! You just became eligible to get driving license. Go Drive!')
}
else{
    console.log('Sorry! You are not eligible to get driving licence')   
}
