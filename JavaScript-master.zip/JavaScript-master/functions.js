
// function funcName(param1, param2){
//     //statments
// }

function add(a, b){
    // console.log (a + b);
    return (a + b)
}

let result = add(2, 4);
console.log (result);
